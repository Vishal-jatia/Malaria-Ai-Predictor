GLOBAL HEALTH OBSERVATORY DOWNLOAD
====================================
This zip data file has been downloaded from 

	Name: Malaria treatment and intervention coverage
	URL: https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/malaria-treatment-intervention-coverage
	Description: 
	Malaria transmission occurs in 85 countries across five WHO regions. Since 2015, the WHO European Region has been free of malaria.�According to the World Malaria Report 2020, there were 241 million cases of malaria globally in 2020 (uncertainty range 218�269 million) and 627 000 malaria deaths (uncertainty range 583�765 thousand). Malaria case incidence reduced from 81   in 2000 to 59 in 2015 and 56 in 2019, before increasing again to 59 in 2020. Globally, malaria deaths reduced steadily over the period 2000�2019, from 896 000 in 2000 to 562 000 in 2015 and to 558 000 in 2019. In 2020, malaria deaths increased     by 12% compared with 2019. The increases in malaria cases are deaths were associated with disruption to services during the COVID-19 pandemic.Malaria burden was heaviest in the WHO African Region, with an estimated 95% of cases and 96% of deaths; 80% of all deaths in this region are among children aged under 5 years.
	
	Date generated: 2022-07-28

It contains csv files divided into two folders: data and codes

	data: contains one csv file per indicator under "Malaria treatment and intervention coverage"
	
	codes: contains one csv file per disaggregation/dimension used in the data files
	


Hierarchy

	parent: malaria
	self: malaria-treatment-intervention-coverage
	children: 
		MALARIA_1STLINE_TREATED	Number of malaria cases treated with any first� line tx courses (including artemisinin-based combination therapies (ACTs))
		GHO	Number of malaria cases treated with artemisinin-based combination therapies (ACTs)
		MALARIA_ACT_TREATED	Number of malaria cases treated with artemisinin-based combination therapies (ACTs)
		MALARIA_IRS_COVERAGE	Number of people protected from malaria by indoor residual spraying (IRS)
		MALARIA_ITN_COVERAGE	Population with access to an insecticide-treated bed net (ITN) for malaria protection (%), modelled
		MALARIA_IPTP3_COVERAGE	Pregnant women attending antenatal care at least once and receiving at least 3 doses of Intermittent Preventive Treatment of Malaria for Pregnant Women (IPTp3) (%)
	
